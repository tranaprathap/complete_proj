package com.stockpurchase.utils;

public class StringConstants {

	private final static String STOCK_DATA_SYMBOL= "MSFT";
}
